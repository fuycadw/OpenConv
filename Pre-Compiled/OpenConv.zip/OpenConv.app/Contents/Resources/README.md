OpenConv
========

Open source version of Conv, a Mac OS X encoding converter.
